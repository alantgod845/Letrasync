package com.letrasync.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object LyricsEngine {
    // Si Google cambia el nombre del modelo, edita solo esta línea.
    private const val MODEL = "gemini-2.5-flash"
    private const val MAX_BYTES = 14_000_000

    private fun http(url: String, body: String? = null, apiKey: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 180000
        c.setRequestProperty("User-Agent", "LetraSync/1.0")
        if (apiKey != null) c.setRequestProperty("x-goog-api-key", apiKey)
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: ${text.take(200)}")
        return text
    }

    private fun str(o: JSONObject?, k: String): String? =
        if (o == null || o.isNull(k)) null else o.getString(k).takeIf { it.isNotBlank() }

    private fun lrclib(title: String, artist: String, secs: Int): JSONObject? {
        fun e(s: String) = URLEncoder.encode(s, "UTF-8")
        try {
            return JSONObject(http("https://lrclib.net/api/get?track_name=${e(title)}&artist_name=${e(artist)}&duration=$secs"))
        } catch (_: Exception) {}
        try {
            val arr = JSONArray(http("https://lrclib.net/api/search?q=${e("$artist $title".trim())}"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (str(o, "syncedLyrics") != null) return o
            }
            if (arr.length() > 0) return arr.getJSONObject(0)
        } catch (_: Exception) {}
        return null
    }

    private fun gemini(key: String, audio: ByteArray, plain: String?): String {
        val prompt = if (plain == null)
            "Escucha la canción, transcribe la letra completa y devuelve SOLO formato LRC: una línea por frase con la marca [mm:ss.xx] al inicio, exacta al momento en que se canta. Sin explicaciones ni bloques de código."
        else
            "Escucha la canción y sincroniza esta letra con el momento real en que se canta cada línea. Devuelve SOLO formato LRC: una línea por frase con la marca [mm:ss.xx] al inicio. Mantén el texto de la letra tal cual. Sin explicaciones ni bloques de código.\n\nLetra:\n$plain"
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "audio/mp3")
                .put("data", Base64.encodeToString(audio, Base64.NO_WRAP))))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        val res = JSONObject(http(
            "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent",
            body.toString(), key))
        val text = res.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        return text.lines().filter { !it.trim().startsWith("```") }.joinToString("\n").trim()
    }

    /** Devuelve (letra en formato LRC, mensaje de estado). */
    fun run(ctx: Context, uri: Uri, title: String, artist: String, secs: Int, key: String): Pair<String, String> {
        val hit = lrclib(title, artist, secs)
        val synced = str(hit, "syncedLyrics")
        if (synced != null) return synced to "Letra sincronizada encontrada en LRCLIB ✔"
        val plain = str(hit, "plainLyrics")
        if (key.isBlank()) throw Exception("No hay letra sincronizada en LRCLIB. Agrega tu clave de Gemini en Ajustes.")
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw Exception("No se pudo leer el archivo.")
        if (bytes.size > MAX_BYTES) throw Exception("El archivo es muy grande (máximo ~14 MB).")
        val lrc = gemini(key, bytes, plain)
        val msg = if (plain != null) "Letra encontrada y sincronizada con Gemini ✔" else "Letra generada con Gemini ✔ (revísala)"
        return lrc to msg
    }
}
