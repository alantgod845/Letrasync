package com.letrasync.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val items = listOf("Inicio" to Icons.Default.Home, "Procesar" to Icons.Default.Add, "Ajustes" to Icons.Default.Settings)
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (label, icon) ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen { tab = 1 }
                1 -> ProcessScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("LetraSync", style = MaterialTheme.typography.headlineLarge)
        Text("Elige un MP3 y la app busca su letra en internet y la deja sincronizada en un archivo .lrc que puedes usar en tu reproductor.")
        Button(onClick = onStart) { Text("Empezar") }
    }
}

@Composable
fun ProcessScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var artist by rememberSaveable { mutableStateOf("") }
    var seconds by rememberSaveable { mutableIntStateOf(0) }
    var status by rememberSaveable { mutableStateOf("") }
    var lrc by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u; lrc = ""; status = ""
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, u)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
                artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                seconds = ((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000).toInt()
            } catch (e: Exception) {
                title = ""; artist = ""; seconds = 0
            } finally {
                r.release()
            }
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u ->
        if (u != null) {
            ctx.contentResolver.openOutputStream(u)?.use { it.write(lrc.toByteArray()) }
            status = "Archivo .lrc guardado ✔"
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Procesar canción", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
            Text(if (uri == null) "Elegir archivo MP3" else "Cambiar archivo")
        }
        if (uri != null) {
            OutlinedTextField(title, { title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(artist, { artist = it }, label = { Text("Artista") }, modifier = Modifier.fillMaxWidth())
            Button(enabled = !busy && title.isNotBlank(), onClick = {
                val key = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("gemini_key", "") ?: ""
                scope.launch {
                    busy = true; lrc = ""; status = "Buscando letra…"
                    try {
                        val res = withContext(Dispatchers.IO) {
                            LyricsEngine.run(ctx, uri!!, title.trim(), artist.trim(), seconds, key)
                        }
                        lrc = res.first; status = res.second
                    } catch (e: Exception) {
                        status = "Error: ${e.message}"
                    }
                    busy = false
                }
            }) { Text("Buscar y sincronizar letra") }
        }
        if (busy) CircularProgressIndicator()
        if (status.isNotEmpty()) Text(status)
        if (lrc.isNotEmpty()) {
            val fileName = title.ifBlank { "cancion" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            Button(onClick = { saver.launch("$fileName.lrc") }) { Text("Guardar archivo .lrc") }
            Text(lrc, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    var key by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineSmall)
        Text("Clave de Gemini API. Se guarda solo en tu teléfono. Puedes crearla en aistudio.google.com.")
        OutlinedTextField(
            key, { key = it; saved = false }, label = { Text("Clave de API") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth())
        Button(onClick = { prefs.edit().putString("gemini_key", key.trim()).apply(); saved = true }) { Text("Guardar") }
        if (saved) Text("Clave guardada ✔")
    }
}
